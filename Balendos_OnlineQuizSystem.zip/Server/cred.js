const CRED = {
    "DB":"mongodb+srv://testboi:auto1234@swe.xrvks.mongodb.net/app?retryWrites=true&w=majority",
    "SECRET": "AdanAtherHadiKhizarPenYeawo"
};

module.exports = CRED;